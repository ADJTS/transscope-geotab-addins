/* ============================================================================
   EV Fleet Dashboard — MyGeotab Add-In
   ----------------------------------------------------------------------------
   Reads live EV data from the MyGeotab API:
     - Device                      list of vehicles
     - StatusData                  latest reported diagnostic values
         DiagnosticStateOfChargeId               (%% state of charge)
         DiagnosticElectricVehicleChargingStateId (0 not charging / 1 AC / 2 DC)
     - BatteryStateOfHealth        battery degradation vs. original capacity
     - ChargeEvent                 completed charging session history

   The toolbar's charging-period filter (current/last week, last month,
   custom range) only scopes the "Total Charged" KPI's ChargeEvent lookup —
   live status (state of charge, charging now, current kWh) always reflects
   the last LOOKBACK_HOURS.

   Diagnostic IDs and object schemas are per the MyGeotab SDK / API reference
   (developers.geotab.com). Diagnostic support varies by OEM/telematics
   device — confirm availability for your fleet with:
       api.call("Get", { typeName: "Diagnostic", search: { searchText: "state of charge" } })
   before relying on this in production.
   ========================================================================= */

(function () {
  "use strict";

  // Flip to false once wired to a live MyGeotab session; true lets the page
  // render with realistic sample data when opened outside MyGeotab (e.g.
  // for design review) or if a live call fails.
  var DEMO_MODE_FALLBACK = true;

  // MyGeotab's host shell injects `window.geotab` before this script runs;
  // outside that host (opening index.html directly for design review) it
  // doesn't exist, so nothing would ever call initialize()/focus() below.
  // Stub it in that case only, and self-bootstrap the demo view at the
  // bottom of this file — a no-op once a real host is present.
  var STANDALONE_PREVIEW = typeof window.geotab === "undefined";
  if (STANDALONE_PREVIEW) {
    window.geotab = { addin: {} };
  }

  var SOC_DIAGNOSTIC_ID = "DiagnosticStateOfChargeId";
  var CHARGE_STATE_DIAGNOSTIC_ID = "DiagnosticElectricVehicleChargingStateId";
  var CHARGE_STATE_LABEL = { 0: "Not charging", 1: "AC charging", 2: "DC fast charging" };
  var LOOKBACK_HOURS = 24;

  // ---- Charging-period filter: controls the date range used only for the
  // ---- "Total Charged" KPI (ChargeEvent aggregation). Live status (state of
  // ---- charge, charging now, current kWh) always reflects the last
  // ---- LOOKBACK_HOURS, independent of this filter.
  function startOfWeek(d) {
    var date = new Date(d);
    var day = date.getDay();
    var diff = day === 0 ? -6 : 1 - day;
    date.setDate(date.getDate() + diff);
    date.setHours(0, 0, 0, 0);
    return date;
  }

  function getPeriodRange(period, customFrom, customTo) {
    var now = new Date();
    if (period === "last_week") {
      var thisWeekStart = startOfWeek(now);
      var from = new Date(thisWeekStart);
      from.setDate(from.getDate() - 7);
      var to = new Date(thisWeekStart);
      to.setMilliseconds(-1);
      return { from: from, to: to, label: "Last Week" };
    }
    if (period === "last_month") {
      var y = now.getFullYear(), m = now.getMonth();
      var lmFrom = new Date(y, m - 1, 1, 0, 0, 0, 0);
      var lmTo = new Date(y, m, 1, 0, 0, 0, 0);
      lmTo.setMilliseconds(-1);
      return { from: lmFrom, to: lmTo, label: "Last Month" };
    }
    if (period === "custom") {
      var cFrom = customFrom ? new Date(customFrom + "T00:00:00") : startOfWeek(now);
      var cTo = customTo ? new Date(customTo + "T23:59:59") : now;
      return { from: cFrom, to: cTo, label: "Custom Range" };
    }
    // default: current_week
    return { from: startOfWeek(now), to: now, label: "Current Week" };
  }

  geotab.addin.evFleetDashboard = function () {
    var elTableBody = document.getElementById("evfdTableBody");
    var elKpis = document.getElementById("evfdKpis");
    var elChargeCards = document.getElementById("evfdChargeCards");
    var elAlerts = document.getElementById("evfdAlerts");
    var elComposition = document.getElementById("evfdComposition");
    var elSyncText = document.getElementById("evfdSyncText");
    var elRefreshBtn = document.getElementById("evfdRefreshBtn");
    var elPeriodSelect = document.getElementById("evfdPeriodSelect");
    var elCustomRange = document.getElementById("evfdCustomRange");
    var elCustomFrom = document.getElementById("evfdCustomFrom");
    var elCustomTo = document.getElementById("evfdCustomTo");

    function loadAndRender(api) {
      var liveFromDate = new Date(Date.now() - LOOKBACK_HOURS * 3600 * 1000).toISOString();
      var period = getPeriodRange(elPeriodSelect.value, elCustomFrom.value, elCustomTo.value);

      api.multiCall([
        ["Get", { typeName: "Device", search: { fromDate: liveFromDate } }],
        ["Get", { typeName: "StatusData", search: { diagnosticSearch: { id: SOC_DIAGNOSTIC_ID }, fromDate: liveFromDate } }],
        ["Get", { typeName: "StatusData", search: { diagnosticSearch: { id: CHARGE_STATE_DIAGNOSTIC_ID }, fromDate: liveFromDate } }],
        ["Get", { typeName: "BatteryStateOfHealth", search: {} }],
        ["Get", { typeName: "ChargeEvent", search: { fromDate: liveFromDate } }],
        ["Get", { typeName: "ChargeEvent", search: { fromDate: period.from.toISOString(), toDate: period.to.toISOString() } }]
      ], function (results) {
        try {
          var model = buildModel(results[0], results[1], results[2], results[3], results[4]);
          model.totalDeviceCount = (results[0] || []).length;
          model.totalChargedKwh = sumEnergyKwh(results[5]);
          model.periodLabel = period.label;
          render(model);
          elSyncText.textContent = "Synced " + new Date().toLocaleTimeString();
        } catch (e) {
          console.error("EV Fleet Dashboard: failed to process API results", e);
          if (DEMO_MODE_FALLBACK) render(mockModel());
        }
      }, function (err) {
        console.error("EV Fleet Dashboard: MyGeotab API call failed", err);
        elSyncText.textContent = DEMO_MODE_FALLBACK ? "Sample data (API unavailable)" : "Error loading data";
        if (DEMO_MODE_FALLBACK) render(mockModel());
      });
    }

    // ChargeEvent's energy field per developers.geotab.com is
    // measuredEnergyConsumption (kWh); confirm against your database with
    // GetEntity before relying on this in production.
    function sumEnergyKwh(chargeEvents) {
      return (chargeEvents || []).reduce(function (sum, ce) {
        return sum + (typeof ce.measuredEnergyConsumption === "number" ? ce.measuredEnergyConsumption : 0);
      }, 0);
    }

    // Reduce a StatusData array to the single latest record per device.
    function latestByDevice(statusRows) {
      var map = {};
      (statusRows || []).forEach(function (row) {
        var id = row.device && row.device.id;
        if (!id) return;
        if (!map[id] || new Date(row.dateTime) > new Date(map[id].dateTime)) map[id] = row;
      });
      return map;
    }

    function buildModel(devices, socRows, chargeRows, sohRows, chargeEvents) {
      var socByDevice = latestByDevice(socRows);
      var chargeStateByDevice = latestByDevice(chargeRows);

      var sohByDevice = {};
      (sohRows || []).forEach(function (r) {
        var id = r.device && r.device.id;
        if (id) sohByDevice[id] = r;
      });

      var lastChargeEventByDevice = {};
      (chargeEvents || []).forEach(function (ce) {
        var id = ce.device && ce.device.id;
        if (!id) return;
        if (!lastChargeEventByDevice[id] || new Date(ce.startTime) > new Date(lastChargeEventByDevice[id].startTime)) {
          lastChargeEventByDevice[id] = ce;
        }
      });

      // A device only counts as "EV" here if it has reported a state-of-charge
      // reading in the lookback window.
      var vehicles = (devices || [])
        .filter(function (d) { return !!socByDevice[d.id]; })
        .map(function (d) {
          var soc = Math.round(socByDevice[d.id].data);
          var chargeStateVal = chargeStateByDevice[d.id] ? Math.round(chargeStateByDevice[d.id].data) : 0;
          var soh = sohByDevice[d.id];
          var sohPct = soh ? Math.round(soh.stateOfHealthMean * 100) : null;
          var capacityKwh = soh ? soh.currentBatteryCapacityMeanKwh : null;
          var lastEvent = lastChargeEventByDevice[d.id] || null;

          var estRangeKm = capacityKwh != null
            ? Math.round(capacityKwh * (soc / 100) * 5.5) // ~5.5 km/kWh, adjust per fleet's real consumption
            : null;

          return {
            id: d.id,
            name: d.name || d.id,
            soc: soc,
            sohPct: sohPct,
            estRangeKm: estRangeKm,
            chargeState: chargeStateVal,
            lastReport: socByDevice[d.id].dateTime,
            lastChargeEvent: lastEvent,
            capacityKwh: capacityKwh
          };
        });

      return { vehicles: vehicles };
    }

    function statusFor(v) {
      if (v.soc <= 15) return "critical";
      if (v.sohPct != null && v.sohPct < 80) return "fair";
      if (v.soc <= 35) return "poor";
      if (v.sohPct != null && v.sohPct < 90) return "good";
      return "excellent";
    }

    function timeAgo(iso) {
      var mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
      if (mins < 1) return "<1 min ago";
      if (mins < 60) return mins + " min ago";
      return Math.round(mins / 60) + " hr ago";
    }

    function render(model) {
      renderKpis(model.vehicles, model.totalDeviceCount, model.totalChargedKwh, model.periodLabel);
      renderComposition(model.vehicles, model.totalDeviceCount);
      renderTable(model.vehicles);
      renderChargeCards(model.vehicles);
      renderAlerts(model.vehicles);
    }

    function renderKpis(vehicles, totalDeviceCount, totalChargedKwh, periodLabel) {
      var charging = vehicles.filter(function (v) { return v.chargeState !== 0; });
      var ac = charging.filter(function (v) { return v.chargeState === 1; }).length;
      var dc = charging.filter(function (v) { return v.chargeState === 2; }).length;
      var fleetTotal = totalDeviceCount || vehicles.length;
      var evPct = fleetTotal ? Math.round((vehicles.length / fleetTotal) * 100) : 0;

      var withCapacity = vehicles.filter(function (v) { return v.capacityKwh != null; });
      var currentKwhTotal = withCapacity.reduce(function (s, v) { return s + v.capacityKwh * (v.soc / 100); }, 0);
      var avgKwh = withCapacity.length ? currentKwhTotal / withCapacity.length : 0;

      elKpis.innerHTML = [
        kpiCard("Total Vehicles", fleetTotal, ""),
        kpiCard("EV Vehicles", vehicles.length, evPct + "% of fleet", "accent"),
        kpiCard("Charging Now", charging.length, ac + " AC · " + dc + " DC fast"),
        kpiCard("Current Charge", Math.round(currentKwhTotal) + " kWh", withCapacity.length ? "avg " + avgKwh.toFixed(1) + " kWh/EV" : ""),
        kpiCard("Total Charged", Math.round(totalChargedKwh || 0) + " kWh", periodLabel || "")
      ].join("");
    }

    function renderComposition(vehicles, totalDeviceCount) {
      var fleetTotal = totalDeviceCount || vehicles.length;
      var evCount = vehicles.length;
      var fossilCount = Math.max(fleetTotal - evCount, 0);
      var evPct = fleetTotal ? Math.round((evCount / fleetTotal) * 100) : 0;
      var fossilPct = fleetTotal ? 100 - evPct : 0;

      elComposition.innerHTML =
        '<div class="evfd-comp-bar">' +
          '<span class="ev-seg" style="width:' + evPct + '%;"></span>' +
          '<span class="fossil-seg" style="width:' + fossilPct + '%;"></span>' +
        '</div>' +
        '<div class="evfd-comp-legend">' +
          '<div class="evfd-comp-legend-item"><span class="evfd-comp-swatch ev-seg"></span><span class="evfd-comp-legend-label">Electric</span><span class="evfd-comp-legend-value evfd-num">' + evCount + ' (' + evPct + '%)</span></div>' +
          '<div class="evfd-comp-legend-item"><span class="evfd-comp-swatch fossil-seg"></span><span class="evfd-comp-legend-label">Fossil Fuel</span><span class="evfd-comp-legend-value evfd-num">' + fossilCount + ' (' + fossilPct + '%)</span></div>' +
        '</div>';
    }

    function kpiCard(label, value, sub, tone) {
      return '<div class="evfd-kpi-card">' +
        '<div class="evfd-kpi-label">' + label + '</div>' +
        '<div class="evfd-kpi-value evfd-num' + (tone ? " " + tone : "") + '">' + value + '</div>' +
        (sub ? '<div class="evfd-kpi-sub">' + sub + '</div>' : '') +
        '</div>';
    }

    function renderTable(vehicles) {
      if (!vehicles.length) {
        elTableBody.innerHTML = '<tr><td colspan="7" class="evfd-loading-row">No EVs reporting state-of-charge data in the last ' + LOOKBACK_HOURS + 'h.</td></tr>';
        return;
      }
      elTableBody.innerHTML = vehicles
        .sort(function (a, b) { return a.soc - b.soc; })
        .map(function (v) {
          var status = statusFor(v);
          var meterColor = "var(--evfd-status-" + status + ")";
          var currentKwh = v.capacityKwh != null ? (v.capacityKwh * (v.soc / 100)).toFixed(1) : null;
          var chargeChip = v.chargeState === 0
            ? '<span class="evfd-chip evfd-chip-idle">Not charging</span>'
            : '<span class="evfd-chip" style="background:rgba(47,125,209,.15);color:var(--evfd-chg-' + (v.chargeState === 2 ? 'dc' : 'ac') + ');"><span class="evfd-cdot" style="background:var(--evfd-chg-' + (v.chargeState === 2 ? 'dc' : 'ac') + ');"></span>' + CHARGE_STATE_LABEL[v.chargeState] + '</span>';

          return '<tr>' +
            '<td class="evfd-veh-id">' + escapeHtml(v.name) + '</td>' +
            '<td><div class="evfd-meter-cell"><div class="evfd-meter"><span style="width:' + v.soc + '%;background:' + meterColor + ';"></span></div><span class="evfd-meter-val evfd-num">' + v.soc + '%</span></div></td>' +
            '<td class="evfd-num">' + (currentKwh != null ? currentKwh + " kWh" : "—") + '</td>' +
            '<td class="evfd-num">' + (v.sohPct != null ? v.sohPct + "%" : "—") + '</td>' +
            '<td class="evfd-num">' + (v.estRangeKm != null ? v.estRangeKm + " km" : "—") + '</td>' +
            '<td>' + chargeChip + '</td>' +
            '<td>' + timeAgo(v.lastReport) + '</td>' +
            '</tr>';
        }).join("");
    }

    function renderChargeCards(vehicles) {
      var charging = vehicles.filter(function (v) { return v.chargeState !== 0; });
      if (!charging.length) {
        elChargeCards.innerHTML = '<p class="evfd-muted" style="padding:0 2px;">No vehicles are currently charging.</p>';
        return;
      }
      elChargeCards.innerHTML = charging.slice(0, 6).map(function (v) {
        var badge = v.chargeState === 2 ? '<span class="evfd-badge dc">DC FAST</span>' : '<span class="evfd-badge ac">AC LEVEL 2</span>';
        // Time-to-full is a rough estimate: (remaining kWh) / (last observed
        // charge power). Real charge curves taper near 100% — treat as
        // indicative only, not a guarantee.
        var eta = "—";
        var ev = v.lastChargeEvent;
        if (v.capacityKwh && ev && ev.peakPowerKw) {
          var remainingKwh = v.capacityKwh * (1 - v.soc / 100);
          var hours = remainingKwh / ev.peakPowerKw;
          eta = hours < 1 ? Math.round(hours * 60) + "m" : hours.toFixed(1) + "h";
        }
        return '<div class="evfd-charge-card">' +
          '<div class="evfd-charge-top"><span class="evfd-veh-id">' + escapeHtml(v.name) + '</span>' + badge + '</div>' +
          '<div class="evfd-cbar"><span style="width:' + v.soc + '%;background:var(--evfd-chg-' + (v.chargeState === 2 ? 'dc' : 'ac') + ');"></span></div>' +
          '<div class="evfd-charge-meta"><span>' + v.soc + '% state of charge</span><span>Est. to full: ' + eta + '</span></div>' +
          '</div>';
      }).join("");
    }

    function renderAlerts(vehicles) {
      var alerts = [];
      vehicles.forEach(function (v) {
        if (v.soc <= 15) alerts.push({ sev: "critical", title: "Low state of charge — " + v.name, detail: v.soc + "% SoC" + (v.estRangeKm != null ? ", " + v.estRangeKm + " km est. range" : "") });
        if (v.sohPct != null && v.sohPct < 80) alerts.push({ sev: "warn", title: "Battery health degrading — " + v.name, detail: "State of health at " + v.sohPct + "%" });
      });
      if (!alerts.length) {
        elAlerts.innerHTML = '<p class="evfd-muted" style="padding:14px 18px;">No active alerts.</p>';
        return;
      }
      elAlerts.innerHTML = alerts.map(function (a) {
        return '<div class="evfd-alert-item"><span class="evfd-alert-rail ' + a.sev + '"></span>' +
          '<div><div class="evfd-alert-title">' + escapeHtml(a.title) + '</div>' +
          '<div class="evfd-alert-detail">' + escapeHtml(a.detail) + '</div></div></div>';
      }).join("");
    }

    function escapeHtml(s) {
      return String(s).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
      });
    }

    // ---- Sample data used only when DEMO_MODE_FALLBACK is true and there is
    // ---- no live MyGeotab session (standalone preview) or a call fails.
    function mockModel() {
      var now = Date.now();
      function mins(n) { return new Date(now - n * 60000).toISOString(); }
      var period = getPeriodRange(elPeriodSelect.value, elCustomFrom.value, elCustomTo.value);
      return {
        totalDeviceCount: 20,
        totalChargedKwh: 842,
        periodLabel: period.label,
        vehicles: [
          { id: "1", name: "EV-032", soc: 74, sohPct: 95, estRangeKm: 201, chargeState: 1, lastReport: mins(1), capacityKwh: 68, lastChargeEvent: { peakPowerKw: 11 } },
          { id: "2", name: "EV-058", soc: 91, sohPct: 97, estRangeKm: 268, chargeState: 2, lastReport: mins(0), capacityKwh: 75, lastChargeEvent: { peakPowerKw: 60 } },
          { id: "3", name: "EV-063", soc: 100, sohPct: 93, estRangeKm: 241, chargeState: 0, lastReport: mins(58), capacityKwh: 72 },
          { id: "4", name: "EV-027", soc: 55, sohPct: 91, estRangeKm: 132, chargeState: 0, lastReport: mins(8), capacityKwh: 64 },
          { id: "5", name: "EV-014", soc: 62, sohPct: 78, estRangeKm: 118, chargeState: 0, lastReport: mins(3), capacityKwh: 60 },
          { id: "6", name: "EV-091", soc: 47, sohPct: 85, estRangeKm: 142, chargeState: 0, lastReport: mins(120), capacityKwh: 77 },
          { id: "7", name: "EV-077", soc: 33, sohPct: 89, estRangeKm: 76, chargeState: 0, lastReport: mins(41), capacityKwh: 58 },
          { id: "8", name: "EV-041", soc: 9, sohPct: 88, estRangeKm: 14, chargeState: 0, lastReport: mins(6), capacityKwh: 62 }
        ]
      };
    }

    function refresh(api) {
      if (!api) {
        if (DEMO_MODE_FALLBACK) render(mockModel());
        return;
      }
      loadAndRender(api);
    }

    return {
      initialize: function (api, state, callback) {
        elRefreshBtn.addEventListener("click", function () { refresh(api); });
        elPeriodSelect.addEventListener("change", function () {
          elCustomRange.hidden = elPeriodSelect.value !== "custom";
          if (elPeriodSelect.value !== "custom") refresh(api);
        });
        elCustomFrom.addEventListener("change", function () { if (elCustomFrom.value && elCustomTo.value) refresh(api); });
        elCustomTo.addEventListener("change", function () { if (elCustomFrom.value && elCustomTo.value) refresh(api); });
        callback();
      },
      focus: function (api) {
        refresh(api);
      },
      blur: function () { /* no teardown needed */ }
    };
  };

  if (STANDALONE_PREVIEW) {
    var addin = geotab.addin.evFleetDashboard();
    addin.initialize(null, {}, function () { addin.focus(null); });
  }
})();
